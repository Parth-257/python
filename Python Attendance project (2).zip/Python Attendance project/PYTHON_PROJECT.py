from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import mysql.connector
import csv
root=Tk()
def TAKE_ATTENDANCE():
    selected_class = class_combobox.get()
    if selected_class == 'Class 4IT-B':
        mydb = mysql.connector.connect(
            host='localhost', user='root', password='', database='attendance_system')
        mycursor = mydb.cursor()

        new_win = Toplevel(root)
        new_win.title("ATTENDANCE PAGE")
        hl = Label(new_win, text="TAKE ATTENDANCE", font=("Helvetica", 16))
        hl.pack()

        mycursor.execute('SELECT * FROM studentlist WHERE Class = "4IT-B"')
        studentlist = mycursor.fetchall()

        attendance = {}  

        canvas = Canvas(new_win, height=400)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar = Scrollbar(new_win, orient=VERTICAL, command=canvas.yview)
        scrollbar.pack(side=RIGHT, fill=Y)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        frame = Frame(canvas)
        canvas.create_window((0, 0), window=frame, anchor="nw")

        for student in studentlist:
            var = IntVar()
            var.set(1) 
            cb = Checkbutton(frame, text=f"{student[0]}  |  {student[1]}  |  {student[2]}  |  {student[3]} ", font=("Quadrat", 12), variable=var)
            cb.pack()
            attendance[student[0]] = var  

        def SUBMIT_A():
            try:
                for student_id, var in attendance.items():
                    student_present = var.get() 
                    if student_present == 1:
                        attendance_status = 'Present'
                    else:
                        attendance_status = 'Absent'

                    mycursor.execute("SELECT Name, Enrollment FROM studentlist WHERE id = %s", (student_id,))
                    student_info = mycursor.fetchone()

                    sql = "INSERT INTO attendance_data (student_id, attendance_status) VALUES (%s, %s)"
                    val = (student_id, attendance_status)
                    mycursor.execute(sql, val)

                mydb.commit()  
                mydb.close()

                with open('attendance_a.csv', 'w', newline='') as csvfile:
                    fieldnames = ['Student ID', 'Name', 'Enrollment', 'Attendance Status']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    for student_id, var in attendance.items():
                        student_present = var.get()
                        if student_present == 1:
                            attendance_status = 'Present'
                        else:
                            attendance_status = 'Absent'
                        student_info = studentlist[student_id - 1]
                        writer.writerow({'Student ID': student_id, 'Name': student_info[1],
                                         'Enrollment': student_info[2], 'Attendance Status': attendance_status})

                   
               

            except Exception as e:
               
                messagebox.showerror("Error", str(e))

        submit_button = Button(new_win, text="Submit", font=("Helvetica", 14), command=SUBMIT_A)
        submit_button.pack(pady=20)

    
    elif selected_class == 'Class 4CE-B':
        mydb = mysql.connector.connect(
            host='localhost', user='root', password='', database='attendance_system')
        mycursor = mydb.cursor()

        new_win = Toplevel(root)
        new_win.title("ATTENDANCE PAGE")
        hl = Label(new_win, text="TAKE ATTENDANCE", font=("Helvetica", 16))
        hl.pack()

        mycursor.execute('SELECT * FROM studentlist_b WHERE Class = "4CE-B"')
        studentlist = mycursor.fetchall()

        attendance = {}  
        # canvas = Canvas(new_win, height=400)
        # canvas.pack(side=LEFT, fill=BOTH, expand=True)
        # scrollbar = Scrollbar(new_win, orient=VERTICAL, command=canvas.yview)
        # scrollbar.pack(side=RIGHT, fill=Y)
        # canvas.configure(yscrollcommand=scrollbar.set)
        # canvas.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        # frame = Frame(canvas)
        # canvas.create_window((0, 0), window=frame, anchor="nw")

        for student in studentlist:
            var = IntVar()
            var.set(1) 
            cb = Checkbutton(new_win, text=f"id:{student[0]}    |    Name:{student[1]}  |     Enrollment:{student[2]}  | Class:{student[3]} ",
                              font=("Helvetica", 12), variable=var)
            cb.pack()
            attendance[student[0]] = var  

        def SUBMIT():
            mydb = mysql.connector.connect(
                host='localhost', user='root', password='', database='attendance_system')
            mycursor = mydb.cursor()

            for student_id, var in attendance.items():
                student_present = var.get() 
                if student_present == 1:
                    attendance_status = 'Present'
                else:
                    attendance_status = 'Absent'

                mycursor.execute("SELECT Name, Enrollment FROM studentlist_b WHERE id = %s", (student_id,))
                student_info = mycursor.fetchone()


                sql = "INSERT INTO attendance_data1 (student_id_b, attendance_status_b) VALUES (%s, %s)"
                val = (student_id, attendance_status)
                mycursor.execute(sql, val)

            mydb.commit()  
            mydb.close()  
            with open('attendance_b.csv', 'w', newline='') as csvfile:
                    fieldnames = ['Student ID', 'Name', 'Enrollment', 'Attendance Status']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    for student_id, var in attendance.items():
                        student_present = var.get()
                        if student_present == 1:
                            attendance_status = 'Present'
                        else:
                            attendance_status = 'Absent'
                        student_info = studentlist[student_id - 1]
                        writer.writerow({'Student ID': student_id, 'Name': student_info[1],
                                         'Enrollment': student_info[2], 'Attendance Status': attendance_status})

            messagebox="Success", "Attendance submitted successfully!"





        submit_button = Button(new_win, text="Submit", font=("Helvetica", 14), command=SUBMIT)
        submit_button.pack(pady=20)


      
    
  



# Heading
hf = Frame(root, borderwidth=4, bg="grey")
hf.pack(fill=X)
heading = Label(hf, text="RK UNIVERSITY", font=("Helvetica", 28, "bold"), fg="green")
heading.pack()

hf1 = Frame(root, borderwidth=4, bg="grey")
hf1.pack(fill=X)
heading1 = Label(hf1, text="STUDENT ATTENDANCE SYSTEM 👨‍🎓", font=("Helvetica", 22, "bold"), fg="blue")
heading1.pack()



# Class Selection
class_frame = Frame(root, pady=20)
class_frame.pack()

class_label = Label(class_frame, text="Select Class:", font=("Helvetica", 14))
class_label.pack(side=LEFT, pady=40, padx=10)

selected_option = StringVar()
class_combobox = ttk.Combobox(
    class_frame, textvariable=selected_option, state='readonly')
class_combobox['values'] = ('Class 4IT-B', 'Class 4CE-B')
class_combobox.current(0)
class_combobox.pack(side=LEFT)

bf = Frame(root, borderwidth=4, bg="grey")
bf.pack()
button1 = Button(bf, text="Take Attendance", font=("Quadrat",
 20, "bold"), command=TAKE_ATTENDANCE)
button1.pack()






gf = Frame(root, borderwidth=4)
gf.pack()



root.mainloop()  
 

root.mainloop()  



